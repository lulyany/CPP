# README

studenet number: 520370910039

## EX1

1. ​       				               		Shape

   ​			             /                          	   		   		  |											\

   ​				Rectangle 						    				Circle										Group(truck)

   ​		/			|              \											|

   cliff 		truck body	truck head					truck wheel 



Truck is a "group" of :2 rectangles, 2 cycles.   

cliff is a rectangle.

rectangle------methods:move,change direction, draw

​		  ------attributes:point pt1,pt2

Circle----------methods:move change direction, draw

​			 --------attributes:point pt1, radius

## ex2

1/2.

​					device

/       					/					\						\

American		Australlia		Asian				European

method:a function that prompt the user to choose one of the devices

Attributes:the value of x





​								button

/       					/					\						\

A						B						C					D

Methods: defferent ways of caculation , and prompt the user the next button 

  Attributes: value of x 

protected

and public class, because we should use the parent attributes and methods

3.class Device{

Private:

Public:

}

4.

cin>> input

if 1

{

American

then do ABCD recursion

}





