#ifndef _DIST_IMPL_H_
#define _DIST_IMPL_H_

#include "dlist.h"

#include <iostream>
#include <string>
#include <cstdlib>
#include <cassert>

template <class T>
bool Dlist<T>::isEmpty() const
{
     return (first == nullptr && last == nullptr);}
// EFFECTS: returns true if list is empy, false otherwise

template <class T>
void Dlist<T>::insertFront(T *op)
{
    node *np = new node;
    np->op = op;
    // np->next = first;
    // np->prev = nullptr;
    // if (isEmpty())
    // {
    //     first = np;
    //     last = np;
    // }
    // else
    // {
    //     first->prev = np;
    //     first = np;
    // }
    if (isEmpty()) {
        np->next = np->prev = nullptr;
        last = np;
    } else {
        np->next = first;
        first->prev = np;
    }
    first = np;
}
// EFFECTS inserts o at the front of the list

template <class T>
void Dlist<T>::insertBack(T *op)
{
    node *np = new node;
    np->op = op;
    // np->prev = last;
    // np->next = nullptr;
    // if (isEmpty())
    // {
    //     first = np;
    //     last = np;
    // }
    // else
    // {
    //     last->next = np;
    //     last = np;
    // }
    if (isEmpty()) {
        np->next = np->prev = nullptr;
        first = np;
    } else {
        last->next = np;
        np->prev = last;
    }
    last = np;
}
// EFFECTS inserts o at the back of the list

template <class T>
T *Dlist<T>::removeFront()
{
    if (isEmpty())
        throw emptyList();
    node* thisptr = first;
    if (this->first != this->last) {
        node* second = this->first->next;
        second->prev = nullptr;
        this->first = second;
    } else
        this->first = this->last = nullptr;
    T* valueptr = thisptr->op;
    thisptr->op = nullptr;
    thisptr->next = thisptr->prev = nullptr;
    delete thisptr->op;
    delete thisptr;
    return valueptr;
    // if (isEmpty())
    // {
    //     emptyList e;
    //     throw e;
    // }
    // node *victim = first;
    // first = first->next;
    // if (!first)
    // {
    //     last = nullptr;
    // }
    // else
    // {
    //     first->prev = nullptr;
    // }
    // T *result = victim->op;
    // delete victim;
    // //TODO:necessay?
    // // victim = nullptr;
    // return result;
}
// EFFECTS removes and returns first object from non-empty list
//         throws an instance of emptyList if empty

template <class T>
T *Dlist<T>::removeBack()
{
    if (isEmpty())
        throw emptyList();
    node* thisptr = last;
    if (first != last) {
        node* lasttwo = last->prev;
        lasttwo->next = nullptr;
        last = lasttwo;
    } else
        first = last = nullptr;
    thisptr->next = thisptr->prev = nullptr;
    T* valueptr = *thisptr->op;
    valueptr->op = nullptr;
    delete thisptr->op;
    delete thisptr;
    return valueptr;
    // if (isEmpty())
    // {
    //     emptyList e;
    //     throw e;
    // }
    // node *victim = last;
    // last = last->prev;
    // if (!last->prev)
    // {
    //     first = nullptr;
    // }
    // else
    // {
    //     last = nullptr;
    // }
    // T *result = victim->op;
    // delete victim;
    // //TODO:necessay?
    // // victim = nullptr;
    // return result;
}
// EFFECTS removes and returns last object from non-empty list
//         throws an instance of emptyList if empty

template <class T>
Dlist<T>::Dlist() : first(nullptr), last(nullptr) {}
// constructor

template <class T>
Dlist<T>::Dlist(const Dlist &l)
{
    first = last = nullptr;
    // copyAll(l);
        if (this != &l) {
        removeAll();
        copyAll(l);
    }
}
// copy constructor

template <class T>
Dlist<T> &Dlist<T>::operator=(const Dlist &l)
{
    if (this != &l)
    {
        removeAll();
        copyAll(l);
    } // TODO: to be checked
    return *this;
}

template <class T>
Dlist<T>::~Dlist()
{
    removeAll();
}
// destructor

template <class T>
void Dlist<T>::removeAll()
{
    // while (!this->isEmpty())
    // {
    //     removeFront();
    // }
        while (!isEmpty()) {
        T* ptr = removeFront();
        delete ptr;
    }
}
// TODO: to be checked

template <class T>
void Dlist<T>::copyAll(const Dlist &l)
{
    // removeAll();
    // //insertBack(l.removeFront());
    // //wrong: no const
    // if(!l.isEmpty()){
	// 	node *it = l.first;
	// 	while(it){
	// 		T *op_ = new T(*it->op);
	// 		insertBack(op_);
	// 		it = it->next; 
    //          delete op_;
	// 	}
	// }
    
    Dlist<T> newlist;
    node* currentnode = l.first;
    while (currentnode != l.last) {
        T* valueptr = new T(*(currentnode->op));
        insertBack(valueptr);
        currentnode = currentnode->next;
    }

    if (!l.isEmpty()) {
        T* valueptr = new T(*(l.last->op));
        insertBack(valueptr);
    }
}

#endif