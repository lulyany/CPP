/*
 * @Date: 2021-11-11 14:01:15
 * @LastEditTime: 2021-11-11 14:08:09
 * @FilePath: /附件/p3.cpp
 */
#include "simulation.h"

using namespace std;

int main(int argc, char* argv[]) {

    //initialization
    bool verbose = false;
    world_t world;
    //check input

    if (!check_valid_input(argc, argv))
        return 0;

    //switch verbose
    if ((argc == 5) && ((string)argv[4] == "v" || (string)argv[4] == "verbose"))
        verbose = true;

    //init the world & check
    if (!init_world(world, argv[1], argv[2]))
        return 0;

    //print the world
    cout << "Initial state" << endl;

    //print
    print_grid(world.grid);

    for (int i = 0; i < atoi(argv[3]); i++) {
        cout << "Round " << i + 1 << endl;
        for (int j = 0; j < (int)world.numCreatures; j++) {
            move_creature(world.creatures[j], world.grid, verbose);
            if (verbose)
                print_grid(world.grid);
        }
        if (!verbose)
            print_grid(world.grid);
    }

    return 0;
}
